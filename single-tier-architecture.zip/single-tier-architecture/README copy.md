# Water SSO Registration

#### Requires the JRE Argument below
```
-Djsse.enableSNIExtension=false
```
#### Add proxy settings to maven settings.xml
Linux/OSX: ~/.m2/settings.xml<br/>
Windows: <MAVENHOME>/conf/settings.xml
```
  <proxies>
    <proxy>
      <id>optional</id>
      <active>true</active>
      <protocol>http</protocol>
      <!--<username>proxyuser</username>
      <password>proxypass</password>-->
      <host>iss-americas-pitc-cincinnatiz.proxy.corporate.ge.com</host>
      <port>80</port>
      <nonProxyHosts>localhost</nonProxyHosts>
    </proxy>
  </proxies>
```

#### Bower Install
The bower dependencies must be installed prior to building/running the application. You will need to execute the commands below relative to project root.
```
cd src/main/resources/static
bower install
```

#### Download Oracle Driver from Oracle website
Run command below from directory where you have the odbc7.jar
#### Add oracle jbdc driver to maven
```
mvn install:install-file -Dfile=ojdbc7.jar -DgroupId=com.oracle -DartifactId=ojdbc7 -Dversion=12.1.0.2 -Dpackaging=jar
```

#### Run locally
Please note: Due to proxy issues, you need to first perform these steps off the GE network, then rejoin.
Execute the command below to start the application. Once started, the applicaion will be available at http://localhost:8088/registration
```
mvn spring-boot:run
```

#### Run with a profile
```
$ SPRING_PROFILES_ACTIVE=development java -jar gew-registration-service-0.0.1-SNAPSHOT.jar
```

## Docker
Install docker<br/>
https://docs.docker.com/docker-for-windows/<br/>
https://docs.docker.com/docker-for-mac/
### Local
Create an SSH tunnel and log into docker host
```
ssh -N -p 22 de410481@10.227.255.110 -L 3112:10.227.229.136:22
ssh -p 3112 de410481@localhost
```
Build and package into docker image
```
mvn package docker:build -DskipTests
```
Save docker image to local file
```
docker save -o water_registration.docker gew_registration_service/gew-registration-service
```
SCP docker image to docker host
```
scp -P 3112 water_registration.docker de410481@localhost:/home/de410481/
```
### Remote
Load the docker image into docker
```
docker load -i water_registration.docker
```
Instance the image and run the docker container
```
docker run -p 8000:8080 -t gew_registration_service/gew-registration-service
```
Run with specific profile
```
docker run -e “SPRING_PROFILES_ACTIVE=development" -p 8000:8080 -t gew_registration_service/gew-registration-service
```
