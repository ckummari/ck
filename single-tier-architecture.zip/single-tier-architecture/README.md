# single-tier-architecture
IaC
